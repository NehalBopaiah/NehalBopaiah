package com.example.dell.widgets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
  ToggleButton tg;
  CheckBox ch;
  RadioButton rb1;
  RadioButton rb2;
  SeekBar sk;
  Switch s;
  TextView t1;
    TextView t2;
    TextView t3;
    RelativeLayout lay;
    TextView t4;
    ImageView i1;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ch = (CheckBox) findViewById(R.id.checkBox);
        tg = (ToggleButton) findViewById(R.id.toggleButton);
        rb1 = (RadioButton) findViewById(R.id.radioButton);
        rb2 = (RadioButton) findViewById(R.id.radioButton);
       lay = (RelativeLayout) findViewById(R.id.rl);
        sk = (SeekBar) findViewById(R.id.seekBar);
        s = (Switch) findViewById(R.id.switch1);
        t1 = (TextView) findViewById(R.id.textView);
        t2 = (TextView) findViewById(R.id.textView2);
        t3 = (TextView) findViewById(R.id.textView3);
        t4 = (TextView) findViewById(R.id.textView4);
        i1=(ImageView)findViewById(R.id.imageView);
        rg=(RadioGroup)findViewById(R.id.rg);
        RadioButton CheckedRadioButton=(RadioButton)rg.findViewById(rg.getCheckedRadioButtonId());

      /*  tg.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onClick(View v) {
                RelativeLayout lay = (RelativeLayout) findViewById(R.id.rl);
                lay.setBackgroundResource(R.drawable.bach_in);
                int pic = R.drawable.bach_in;
                lay.setBackgroundResource(pic);
            }
        });*/

      tg.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
          @Override
          public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {


              if(isChecked){
                  lay.setBackgroundResource(R.drawable.bach_in);
                  t1.setText("night mode off");
              }
              else
              {
                  lay.setBackgroundResource(android.R.drawable.btn_default);
                  t1.setText("night mode on");

              }

          }
      });

 ch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
     @Override
     public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
         if(isChecked){
             t2.setText("checkbox selected");
         }
         else
         {
             t2.setText("checkbox unselected");
         }
     }
 });
 /* rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(RadioGroup group, int checkedId) {
         RadioButton radioButton=(RadioButton)group.findViewById(checkedId);
          if(radioButton.isChecked()){
             t3.setText(radioButton.getText());
          }

      }
  });*/
   rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
       @Override
       public void onCheckedChanged(RadioGroup group, int checkedId) {
           int id=rg.getCheckedRadioButtonId();
           switch(id)
           {
               case R.id.radioButton:t3.setText("male");
               break;
               case R.id.radioButton2:t3.setText("female");
               break;
           }
       }
   });
   sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
       @Override
       public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        t4.setTextSize(progress);
       // Toast.makeText(getApplicationContext(),String.valueOf(progress),Toast.LENGTH_LONG).show();
       }

       @Override
       public void onStartTrackingTouch(SeekBar seekBar) {

       }

       @Override
       public void onStopTrackingTouch(SeekBar seekBar) {

       }
   });
    s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            i1=(ImageView)findViewById(R.id.imageView);
            Animation startRotateAnimation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);

            if(isChecked)
            {

                i1.startAnimation(startRotateAnimation);
            }
            else
            {
                i1.clearAnimation();
            }
        }
    });
    }
}

package com.example.dell.simplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4;
    EditText edit1, edit2;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.Add);
        b2 = (Button) findViewById(R.id.Sub);
        b3 = (Button) findViewById(R.id.Div);
        b4 = (Button) findViewById(R.id.Mul);
        edit1 = (EditText) findViewById(R.id.Edit1);
        edit2 = (EditText) findViewById(R.id.Edit2);
        text = (TextView) findViewById(R.id.Text);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c =a+b;
                text.setText(Integer.toString(c));


            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c =a-b;
                text.setText(Integer.toString(c));

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                try
                {
                    int c =a/b;
                    text.setText(Integer.toString(c));
                }
           catch (Exception e)
           {
               Toast.makeText(MainActivity.this,"Cant divide",Toast.LENGTH_LONG).show();
           }

            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one=edit1.getText().toString();
                int a=Integer.parseInt(one);
                String two=edit2.getText().toString();
                int b=Integer.parseInt(two);
                int c =a*b;
                text.setText(Integer.toString(c));

            }
        });
    }



}

